﻿using UnityEngine;
using System.Collections;

public class fireball : MonoBehaviour {
	public float speed;
	Vector3 pos;
	bool direction;
	// Use this for initialization
	void Start () {
		speed = 10;
		direction = montyscript.faceRight;

	}
	
	// Update is called once per frame
	void Update () {
		pos = gameObject.transform.position;
		if (direction) {
			pos.x += speed * Time.deltaTime;
		} else {
			pos.x -= speed * Time.deltaTime;
		}
		gameObject.transform.position = pos;

	}
	void OnTriggerEnter2D(Collider2D col){
		Destroy (col.gameObject);
	}
}
