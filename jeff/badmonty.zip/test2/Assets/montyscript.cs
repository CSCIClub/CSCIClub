﻿using UnityEngine;
using System.Collections;

public class montyscript : MonoBehaviour {
	Animator montysAnimation;
	bool walking,shooting;
	public static bool faceRight;
	Object fireball;
	Rigidbody2D montyrigidbody;
	Vector3 pos;
	public float speed;
	// Use this for initialization
	void Start () {
		montysAnimation = GetComponent<Animator> ();
		montyrigidbody = GetComponent<Rigidbody2D> ();
		fireball = Resources.Load ("fireball");
		faceRight = true;
		speed = 2;
	}
	// Update is called once per frame
	void Update () {
		pos = gameObject.transform.position;
		walking = false; 
		shooting = false;
		if (Input.GetKeyDown (KeyCode.Space)) {
			shooting=true;
			Instantiate (fireball, new Vector3 (pos.x, pos.y, pos.z), Quaternion.identity);
			//spawn fireball
		}
		if (Input.GetKeyDown (KeyCode.W)) {
			walking=true;
			montyrigidbody.AddRelativeForce (new Vector2(0, 500));
		}
		if (Input.GetKey (KeyCode.A)) {
			walking=true;
			faceRight=false;
			gameObject.transform.eulerAngles.Set (0,180,0);
			pos.x -=speed*Time.deltaTime;
		}
		if (Input.GetKey (KeyCode.S)) {
			walking=true;
			pos.y-=speed*Time.deltaTime;
		}
		if (Input.GetKey (KeyCode.D)) {
			gameObject.transform.eulerAngles.Set (0,0,0);
			walking=true;
			faceRight=true;
			pos.x += speed*Time.deltaTime;
		}
		gameObject.transform.position = pos;
		montysAnimation.SetBool ("shooting", shooting);
		montysAnimation.SetBool ("walking",walking);
	}

}
