﻿using UnityEngine;
using System.Collections;

public class PlayerFollow : MonoBehaviour {
	GameObject player; 
	Vector3 PlayerPos, CameraPos;
	public float offsetZ=-1, offsetX=0, height=6;
	// Use this for initialization
	void Start () {
		offsetZ = -5;
		offsetX = 0;
		height=4;
		player = GameObject.Find ("Player");
		CameraPos = gameObject.transform.position;
		CameraPos.y = height;
		gameObject.transform.position = CameraPos;
	}
	
	// Update is called once per frame
	void Update () {
		PlayerPos = player.transform.position;
		CameraPos = gameObject.transform.position;
		CameraPos.x = PlayerPos.x+offsetX;
		CameraPos.z = PlayerPos.z+offsetZ;
		gameObject.transform.position = CameraPos;
	}
}
