﻿using UnityEngine;
using System.Collections;

public class CollectItems : MonoBehaviour {
	GameObject otherObject;
	Vector3 scale;
	public float growRate; 
	// Use this for initialization
	void Start () {
		growRate = 0.2f;
	}
	
	// Update is called once per frame
	void OnTriggerEnter(Collider otherCol){
		Destroy (otherCol.gameObject);
		scale = gameObject.transform.localScale;
		scale.x += growRate;
		scale.y += growRate;
		scale.z += growRate; 
		gameObject.transform.localScale = scale;
	}
}
