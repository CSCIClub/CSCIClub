﻿using UnityEngine;
using System.Collections;

public class Collectable : MonoBehaviour {
	public float speed = 0.25f, rotSpeedx = 200,rotSpeedy = 50;
	float startPos;
	float min = -0.25f;
	float max = 0.25f; 
	Vector3 pos,rot;
	bool direction;
	// Use this for initialization
	void Start () {
		direction = false; 
		startPos = gameObject.transform.position.y;
	}
	
	// Update is called once per frame
	void Update () {
		pos = gameObject.transform.position;
		gameObject.transform.Rotate (new Vector3 (rotSpeedx*Time.deltaTime, rotSpeedy*Time.deltaTime, 0));

		if (direction) {
			pos.y+=speed*Time.deltaTime; 
		} 
		else {
			pos.y-=speed*Time.deltaTime;
		}
		//if(pos.y-startPos<=min-startPos||pos.y-startPos>=max-startPos){
		//	direction = !direction;
		//}
		if (pos.y - startPos <= min - startPos) {
			direction = true;
		}
		else if (pos.y-startPos>=max-startPos){
			direction = false; 
		}

		gameObject.transform.position = pos;

	}
}
