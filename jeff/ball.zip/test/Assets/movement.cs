﻿using UnityEngine;
using System.Collections;

public class movement : MonoBehaviour {
	public float thrust;
	Rigidbody player;
	// Use this for initialization
	void Start () {
		thrust = 5;
		player = GetComponent<Rigidbody> ();
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		if (Input.GetKey (KeyCode.W)) {
			player.AddForce(new Vector3(0, 0, thrust));
		} 
		if (Input.GetKey (KeyCode.A)) {
			player.AddForce(new Vector3(-thrust, 0, 0));

		}
		if(Input.GetKey(KeyCode.S)){
			player.AddForce(new Vector3(0, 0, -thrust));
		}
		if(Input.GetKey(KeyCode.D)){
			player.AddForce(new Vector3(thrust, 0, 0));

		}

	}
}
